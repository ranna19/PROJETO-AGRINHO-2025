let laranjeiras = []; // Array para armazenar as árvores de laranja
let colheitadeira; // Variável para a máquina de colheita, agora chamada Colheitadeira
let caminhaoEntrega; // Variável para o caminhão de entrega
let laranjaImg; // Variável para a imagem da laranja (opcional, se quiser usar imagem)
let laranjasColhidasNoTotal = 0; // Contador de laranjas colhidas no total

// Pré-carrega imagens se necessário
function preload() {
    // Exemplo: se você tivesse uma imagem de laranja
    // laranjaImg = loadImage('assets/laranja.png');
}

function setup() {
    createCanvas(800, 500); // Define o tamanho do canvas
    background(135, 206, 235); // Cor do céu (azul claro)

    // Cria algumas laranjeiras
    for (let i = 0; i < 10; i++) {
        let x = random(50, width - 100);
        let y = random(height / 2 + 100, height - 100); // Mais afastadas da linha da cidade
        laranjeiras.push(new Laranjeira(x, y));
    }

    // Inicializa a Colheitadeira
    colheitadeira = new Colheitadeira(50, height - 150);

    // Inicializa o Caminhão de Entrega (fora da tela, à direita)
    caminhaoEntrega = new CaminhaoEntrega(width + 150, height - 100); // Começa fora da tela
}

function draw() {
    background(135, 206, 235); // Redesenha o céu a cada frame

    // Desenha o horizonte da cidade ANTES do campo
    drawCitySkyline();

    // Desenha o campo (gramado)
    fill(100, 200, 70); // Cor verde para o campo
    noStroke();
    rect(0, height / 2, width, height / 2); // Metade inferior do canvas

    // Desenha as laranjeiras
    for (let laranjeira of laranjeiras) {
        laranjeira.display();
        laranjeira.update();
    }

    // --- CORREÇÃO AQUI: Chamar display e move diretamente para colheitadeira e caminhaoEntrega ---

    // Desenha e move a Colheitadeira
    colheitadeira.display();
    colheitadeira.move();

    // Desenha e move o Caminhão de Entrega
    caminhaoEntrega.display();
    caminhaoEntrega.move();
    caminhaoEntrega.checkLaranjasColhidas(); // Verifica se há laranjas para pegar

    // --- FIM DA CORREÇÃO ---

    // Texto para o tema
    fill(0);
    textSize(24);
    textAlign(CENTER);
    text("Agrinho 2025: Festejando a Conexão do Campo à Cidade", width / 2, 30);
    textSize(18);
    text("Laranjas Colhidas: " + laranjasColhidasNoTotal, width / 2, 60);
    text("Clique para mais laranjas!", width / 2, 90);
}

// Função para desenhar o horizonte da cidade
function drawCitySkyline() {
    fill(80, 80, 80); // Cor cinza para os prédios
    noStroke();

    let cityBaseY = height / 2 - 150; // Ajuste para mover a cidade para cima/baixo

    // Prédios simples
    rect(width * 0.1, cityBaseY, 60, 80);
    rect(width * 0.2, cityBaseY - 40, 70, 120);
    rect(width * 0.3, cityBaseY + 20, 50, 60);
    rect(width * 0.4, cityBaseY - 20, 80, 100);
    rect(width * 0.5, cityBaseY + 10, 40, 70);
    rect(width * 0.6, cityBaseY - 50, 75, 130);
    rect(width * 0.7, cityBaseY - 10, 65, 90);
    rect(width * 0.8, cityBaseY - 30, 55, 110);
    rect(width * 0.9, cityBaseY + 10, 45, 70);

    // Janelas
    fill(255, 255, 150);
    rect(width * 0.1 + 10, cityBaseY + 10, 10, 15);
    rect(width * 0.1 + 30, cityBaseY + 10, 10, 15);
    rect(width * 0.2 + 15, cityBaseY - 30, 10, 15);
    rect(width * 0.2 + 45, cityBaseY - 30, 10, 15);
    rect(width * 0.2 + 15, cityBaseY - 10, 10, 15);
}

// Classe Laranjeira
class Laranjeira {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.laranjas = [];
        this.criarLaranjas(5);
    }

    criarLaranjas(num) {
        for (let i = 0; i < num; i++) {
            let offsetX = random(-20, 20);
            let offsetY = random(-50, 0);
            this.laranjas.push(new Laranja(this.x + offsetX, this.y + offsetY));
        }
    }

    display() {
        fill(139, 69, 19);
        rect(this.x, this.y, 20, 50);

        fill(34, 139, 34);
        ellipse(this.x + 10, this.y, 80, 100);

        for (let laranja of this.laranjas) {
            laranja.display();
        }
    }

    update() {
        // Remover laranjas que foram colhidas ou levadas pelo caminhão
        this.laranjas = this.laranjas.filter(laranja => !laranja.colhida && !laranja.entregue);
    }
}

// Classe Laranja
class Laranja {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.diameter = 20;
        this.colhida = false; // Laranja colhida da árvore
        this.entregue = false; // Laranja levada pelo caminhão
        this.yTarget = y; // Posição Y para simular a queda até o chão
    }

    display() {
        if (!this.colhida && !this.entregue) {
            fill(255, 165, 0);
            ellipse(this.x, this.y, this.diameter, this.diameter);
        } else if (this.colhida && !this.entregue) {
            // Se colhida, mas não entregue, simula a laranja no chão esperando o caminhão
            fill(255, 140, 0); // Cor um pouco mais escura para laranjas no chão
            ellipse(this.x, this.yTarget, this.diameter, this.diameter);
        }
    }
}

// --- Classe Colheitadeira ---
class Colheitadeira {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.width = 100;
        this.height = 60;
        this.speed = 1.5;
        this.direction = 1;
    }

    display() {
        // Corpo principal da colheitadeira
        fill(150); // Cinza
        rect(this.x, this.y, this.width, this.height);

        // Cabine
        fill(100);
        rect(this.x + this.width - 30, this.y - 20, 30, 20);

        // Rodas
        fill(50);
        ellipse(this.x + 20, this.y + this.height, 30, 30);
        ellipse(this.x + this.width - 20, this.y + this.height, 30, 30);

        // Braço de colheita
        stroke(0);
        strokeWeight(3);
        line(this.x + this.width / 2, this.y, this.x + this.width / 2, this.y - 40);
        noStroke();
        fill(200, 0, 0);
        rect(this.x + this.width / 2 - 10, this.y - 50, 20, 10);

        // Nome "Colheitadeira"
        fill(0);
        textSize(12);
        textAlign(CENTER);
        text("Colheitadeira", this.x + this.width / 2, this.y + this.height + 40);
    }

    move() {
        this.x += this.speed * this.direction;

        if (this.x + this.width > width || this.x < 0) {
            this.direction *= -1;
        }

        for (let laranjeira of laranjeiras) {
            for (let laranja of laranjeira.laranjas) {
                let distanciaGarraLaranja = dist(this.x + this.width / 2, this.y - 45, laranja.x, laranja.y);
                if (distanciaGarraLaranja < 60 && !laranja.colhida) {
                    laranja.colhida = true;
                    laranja.yTarget = this.y + this.height + 10;
                }
            }
        }
    }
}

// --- Classe CaminhaoEntrega ---
class CaminhaoEntrega {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.width = 150;
        this.height = 80;
        this.speed = 2;
        this.estado = "esperando"; // 'esperando', 'indo', 'coletando', 'voltando'
        this.destinoX = width / 2; // Onde o caminhão vai parar para coletar
    }

    display() {
        // Corpo do caminhão
        fill(0, 100, 200); // Azul escuro
        rect(this.x, this.y, this.width, this.height);

        // Cabine
        fill(0, 70, 150); // Azul mais escuro
        rect(this.x + this.width - 40, this.y - 30, 40, 30);

        // Rodas
        fill(50);
        ellipse(this.x + 30, this.y + this.height, 40, 40);
        ellipse(this.x + this.width - 30, this.y + this.height, 40, 40);

        // Nome "ENTREGA"
        fill(255); // Cor branca para o texto
        textSize(18);
        textAlign(CENTER);
        text("ENTREGA", this.x + this.width / 2, this.y + this.height / 2 + 10);
    }

    move() {
        if (this.estado === "indo") {
            this.x -= this.speed;
            if (this.x <= this.destinoX) {
                this.x = this.destinoX;
                this.estado = "coletando";
            }
        } else if (this.estado === "voltando") {
            this.x += this.speed;
            if (this.x > width + this.width / 2) {
                this.estado = "esperando";
                this.x = width + this.width + 50;
            }
        }
    }

    checkLaranjasColhidas() {
        let laranjasNoChao = 0;
        for (let laranjeira of laranjeiras) {
            for (let laranja of laranjeira.laranjas) {
                if (laranja.colhida && !laranja.entregue) {
                    laranjasNoChao++;
                }
            }
        }

        if (laranjasNoChao > 0 && this.estado === "esperando") {
            this.estado = "indo";
        }

        if (this.estado === "coletando") {
            for (let laranjeira of laranjeiras) {
                for (let laranja of laranjeira.laranjas) {
                    let d = dist(laranja.x, laranja.yTarget, this.x + this.width / 2, this.y + this.height / 2);
                    if (d < 80 && laranja.colhida && !laranja.entregue) {
                        laranja.entregue = true;
                        laranjasColhidasNoTotal++; // Incrementa o contador global
                    }
                }
            }
            let laranjasAindaNoChao = 0;
            for (let laranjeira of laranjeiras) {
                for (let laranja of laranjeira.laranjas) {
                    if (laranja.colhida && !laranja.entregue) {
                        laranjasAindaNoChao++;
                    }
                }
            }
            // O caminhão só volta se realmente coletou alguma laranja nesta rodada
            if (laranjasAindaNoChao === 0 && laranjasColhidasNoTotal > 0 && this.estado === "coletando") {
                 this.estado = "voltando";
            } else if (laranjasAindaNoChao === 0 && this.estado === "coletando") {
                // Se não há laranjas no chão, mas também não coletou nada desta vez (ex: laranjas já foram levadas)
                // O caminhão pode voltar ou ficar esperando, dependendo da sua preferência.
                // Vou fazer ele voltar para evitar que fique parado desnecessariamente.
                this.estado = "voltando";
            }
        }
    }
}

// Interatividade: Clique para criar mais laranjas
function mousePressed() {
    if (laranjeiras.length > 0) {
        let arvoreAleatoria = random(laranjeiras);
        arvoreAleatoria.criarLaranjas(2); // Adiciona 2 laranjas por clique
    }
}